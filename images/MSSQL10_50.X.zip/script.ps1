param(
    [string]$Instance = $(throw "-Instance is required."),
    [string]$Cmd = $(throw "-Cmd is required.")
)

$Id = "MSSQL10_50"

function Install($Instance, $InstallPath) {
    If ([String]::IsNullOrEmpty($InstallPath)) { $InstallPath = $PWD.Path }
    $reg = (Get-Content -Path "$PSScriptRoot\install.reg").Replace("`$ID", "$Id").Replace("`$INSTANCE", "$Instance").Replace("`$INSTALL_PATH", "$($InstallPath.Replace('\', '\\'))");
    $regFile = [System.IO.Path]::GetTempFileName();
    Out-File -FilePath $regFile -Encoding unicode -InputObject $reg;
    REG IMPORT $regFile *>&1 | Out-Null;
    New-Service -Name "MSSQL`$$Instance" `
                -DisplayName "SQL Server ($Instance)" `
                -Description "�ṩ���ݵĴ洢���������ܿط��ʣ����ṩ���ٵ���������" `
                -BinaryPathName "$PSScriptRoot\MSSQL\Binn\sqlservr.exe -s$Instance" `
                -StartupType Automatic;
    Remove-Item -Path $regFile;
    Invoke-Expression "$PSScriptRoot\MSSQL\Binn\sqlservr.exe -s$Instance -m `"SqlSetup`" -q `"Chinese_PRC_CI_AS`" -Q";
}

function Uninstall($Instance) {
    Stop-Service -Name "MSSQL`$$Instance";
    (Get-WmiObject Win32_Service -filter "name='MSSQL`$$Instance'").Delete();
    REG DELETE "HKLM\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL" /v "$Instance" /f *>&1 | Out-Null;
    REG DELETE "HKLM\SOFTWARE\Microsoft\Microsoft SQL Server\$Id.$Instance" /f *>&1 | Out-Null;
    REG DELETE "HKLM\SOFTWARE\Microsoft\Microsoft SQL Server\$Instance" /f *>&1 | Out-Null;
}

function Chport($Instance, $Port) {
}

function Chpass($Instance, $Pass) {
}

switch -regex ($Cmd.Trim()) {
    "^(i|install)$"    {Install $Instance $args[0]; break}
    "^(un|uninstall)$" {Uninstall $Instance; break}
    "^(s|start)$"      {Start-Service -Name "MSSQL`$$Instance"; break}
    "^(p|stop)$"       {Stop-Service -Name "MSSQL`$$Instance"; break}
    "^(r|restart)$"    {Restart-Service -Name "MSSQL`$$Instance"; break}
    "^(q|query)$"      {Get-WmiObject Win32_Service -filter "name='MSSQL`$$Instance'"; break}
    "^(c|cmd)$"        {Invoke-Expression "$PSScriptRoot\MSSQL\Binn\sqlservr.exe -s$Instance $args"; break}
    "^chport$"         {Chport $Instance $args[0]; break}
    "^chpass$"         {Chpass $Instance $args[0]; break}
    Default            {throw "Unknow Cmd"; break}
}
