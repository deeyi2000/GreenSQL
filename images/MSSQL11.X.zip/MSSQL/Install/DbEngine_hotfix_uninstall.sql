/*
**  DbEngine_hotfix_uninstall.SQL
**  Patch uninstall script for database engine component.
*/
