/*
**  SSIS_hotfix_uninstall.SQL
**  Patch uninstall script for the SSIS server catalog (SSISDB).
*/

PRINT '------------------------------------------------------'
PRINT 'Starting execution of SSIS_HOTFIX_UNINSTALL.SQL       '
PRINT '------------------------------------------------------'

DECLARE @run_script BIT
SET @run_script=1

DECLARE @ssis_database_name SYSNAME
SET @ssis_database_name = N'SSISDB'

-- Check whether SSISDB exists
IF(DB_ID(@ssis_database_name) IS NULL)
BEGIN
    SET @run_script=0
    PRINT 'Database SSISDB does not exist in current SQL Server instance'
END

-- Check whether SSISDB is online
IF @run_script <> 0
BEGIN
    DECLARE @state_online SYSNAME
    SET @state_online = 'ONLINE'
    SELECT @state_online = UPPER(@state_online COLLATE SQL_Latin1_General_CP1_CI_AS)

    IF NOT EXISTS (SELECT state_desc FROM master.sys.databases WHERE name = @ssis_database_name AND
        UPPER(state_desc COLLATE SQL_Latin1_General_CP1_CI_AS) LIKE @state_online)
    BEGIN
        SET @run_script=0    
        PRINT 'WARNING! The database SSISDB is not ONLINE. SSIS_HOTFIX_INSTALL.SQL will not be applied. Please run the script manually after the upgrade.'
    END
END

-- Check whether SSISDB is corrupted
IF @run_script <> 0
BEGIN
    IF OBJECT_ID (N'SSISDB.internal.catalog_properties', N'U') IS NULL
    BEGIN
        SET @run_script=0
        PRINT 'Database SSISDB is missing the catalog properties table. The database may be corrupted, or it is not an SSIS Catalog.'
    END
END

IF  @run_script = 0
BEGIN
    PRINT 'Database SSISDB was not patched.'
END
ELSE
BEGIN
    PRINT 'Start applying SSIS_HOTFIX_UNINSTALL changes'

    DECLARE @rawCmd NVARCHAR(MAX), @cmd NVARCHAR(MAX)

    DECLARE  @targetVersion NVARCHAR(256)
    SELECT @targetVersion = CONVERT(NVARCHAR,SERVERPROPERTY(N'ProductVersion'))

    --------------------------------------------------------------------------------------------
    ---------****** Add more version handlers here for future CU versions *****-----------------
    --------------------------------------------------------------------------------------------

    --Version handler for PCU1
    --1. drop the old SP
    IF OBJECT_ID (N'SSISDB.[catalog].[create_execution]', N'P') IS NOT NULL
    BEGIN
        SET @rawCmd = N'DROP PROCEDURE [catalog].[create_execution]'
        SET @cmd = N'EXEC SSISDB.dbo.sp_executesql @statement=N''' + @rawCmd + ''''
        EXEC sp_executesql @cmd

        PRINT 'Stored procedure [catalog].[create_execution] has been dropped.'
    END

    IF OBJECT_ID (N'SSISDB.[catalog].[set_execution_parameter_value]', N'P') IS NOT NULL
    BEGIN
        SET @rawCmd = N'DROP PROCEDURE [catalog].[set_execution_parameter_value]'
        SET @cmd = N'EXEC SSISDB.dbo.sp_executesql @statement=N''' + @rawCmd + ''''
        EXEC sp_executesql @cmd

        PRINT 'Stored procedure [catalog].[set_execution_parameter_value] has been dropped.'
    END

    IF OBJECT_ID (N'SSISDB.[catalog].[configure_catalog]', N'P') IS NOT NULL
    BEGIN
        SET @rawCmd = N'DROP PROCEDURE [catalog].[configure_catalog]'
        SET @cmd = N'EXEC SSISDB.dbo.sp_executesql @statement=N''' + @rawCmd + ''''
        EXEC sp_executesql @cmd

        PRINT 'Stored procedure [catalog].[configure_catalog] has been dropped.'
    END

    IF OBJECT_ID (N'SSISDB.[internal].[cleanup_server_retention_window]', N'P') IS NOT NULL
    BEGIN
        SET @rawCmd = N'DROP PROCEDURE [internal].[cleanup_server_retention_window]'
        SET @cmd = N'EXEC SSISDB.dbo.sp_executesql @statement=N''' + @rawCmd + ''''
        EXEC sp_executesql @cmd

        PRINT 'Stored procedure [internal].[cleanup_server_retention_window] has been dropped.'
    END

    IF OBJECT_ID (N'SSISDB.[internal].[cleanup_server_log]', N'P') IS NOT NULL
    BEGIN
        SET @rawCmd = N'DROP PROCEDURE [internal].[cleanup_server_log]'
        SET @cmd = N'EXEC SSISDB.dbo.sp_executesql @statement=N''' + @rawCmd + ''''
        EXEC sp_executesql @cmd

        PRINT 'Stored procedure [internal].[cleanup_server_log] has been dropped.'
    END

    IF OBJECT_ID (N'SSISDB.[internal].[cleanup_server_execution_keys]', N'P') IS NOT NULL
    BEGIN
        SET @rawCmd = N'DROP PROCEDURE [internal].[cleanup_server_execution_keys]'
        SET @cmd = N'EXEC SSISDB.dbo.sp_executesql @statement=N''' + @rawCmd + ''''
        EXEC sp_executesql @cmd

        PRINT 'Stored procedure [internal].[cleanup_server_execution_keys] has been dropped.'
    END


    IF OBJECT_ID (N'SSISDB.[internal].[get_execution_values]', N'P') IS NOT NULL
    BEGIN
        SET @rawCmd = N'DROP PROCEDURE [internal].[get_execution_values]'
        SET @cmd = N'EXEC SSISDB.dbo.sp_executesql @statement=N''' + @rawCmd + ''''
        EXEC sp_executesql @cmd

        PRINT 'Stored procedure [internal].[get_execution_values] has been dropped.'
    END

    IF OBJECT_ID (N'SSISDB.[internal].[get_execution_property_override_values]', N'P') IS NOT NULL
    BEGIN
        SET @rawCmd = N'DROP PROCEDURE [internal].[get_execution_property_override_values]'
        SET @cmd = N'EXEC SSISDB.dbo.sp_executesql @statement=N''' + @rawCmd + ''''
        EXEC sp_executesql @cmd

        PRINT 'Stored procedure [internal].[get_execution_property_override_values] has been dropped.'
    END

    IF OBJECT_ID (N'SSISDB.[internal].[configure_execution_encryption_algorithm]', N'P') IS NOT NULL
    BEGIN
        SET @rawCmd = N'DROP PROCEDURE [internal].[configure_execution_encryption_algorithm]'
        SET @cmd = N'EXEC SSISDB.dbo.sp_executesql @statement=N''' + @rawCmd + ''''
        EXEC sp_executesql @cmd

        PRINT 'Stored procedure [internal].[configure_execution_encryption_algorithm] has been dropped.'
    END

    IF OBJECT_ID (N'SSISDB.[catalog].[set_execution_property_override_value]', N'P') IS NOT NULL
    BEGIN
        SET @rawCmd = N'DROP PROCEDURE [catalog].[set_execution_property_override_value]'
        SET @cmd = N'EXEC SSISDB.dbo.sp_executesql @statement=N''' + @rawCmd + ''''
        EXEC sp_executesql @cmd

        PRINT 'Stored procedure [catalog].[set_execution_property_override_value] has been dropped.'
    END

    --2. create the new SP
    IF OBJECT_ID (N'SSISDB.[catalog].[create_execution]', N'P') IS NULL
    BEGIN
        SET @rawCmd = N'
        CREATE PROCEDURE [catalog].[create_execution]
            @folder_name nvarchar(128), 
            @project_name nvarchar(128), 
            @package_name nvarchar(260), 
            @reference_id bigint = null, 
            @use32bitruntime bit = 0, 
            @execution_id bigint output
        WITH EXECUTE AS ''''AllSchemaOwner''''
        AS
            SET NOCOUNT ON

            DECLARE @caller_id     int
            DECLARE @caller_name   [internal].[adt_sname]
            DECLARE @caller_sid    [internal].[adt_sid]
            DECLARE @suser_name    [internal].[adt_sname]
            DECLARE @suser_sid     [internal].[adt_sid]
    
            EXECUTE AS CALLER
            EXEC [internal].[get_user_info]
                @caller_name OUTPUT,
                @caller_sid OUTPUT,
                @suser_name OUTPUT,
                @suser_sid OUTPUT,
                @caller_id OUTPUT;
          

            IF(
                EXISTS(SELECT [name]
                    FROM sys.server_principals
                    WHERE [sid] = @suser_sid AND [type] = ''''S'''')  
                OR
                EXISTS(SELECT [name]
                    FROM sys.database_principals
                    WHERE ([sid] = @caller_sid AND [type] = ''''S'''')) 
            )
            BEGIN
                RAISERROR(27123, 16, 1) WITH NOWAIT
                RETURN 1
            END
            REVERT
    
            IF(
                EXISTS(SELECT [name]
                    FROM sys.server_principals
                    WHERE [sid] = @suser_sid AND [type] = ''''S'''')  
                OR
                EXISTS(SELECT [name]
                    FROM sys.database_principals
                    WHERE ([sid] = @caller_sid AND [type] = ''''S'''')) 
            )
            BEGIN
                RAISERROR(27123, 16, 1) WITH NOWAIT
                RETURN 1
            END
    
            DECLARE @created_time datetimeoffset
            DECLARE @return_value   int
            DECLARE @operation_id  bigint
            DECLARE @result     bit
            DECLARE @environment_id bigint
            DECLARE @environment_found bit
    
            IF (@folder_name IS NULL OR @project_name IS NULL 
                OR @package_name IS NULL OR @use32bitruntime IS NULL)
            BEGIN
                RAISERROR(27138, 16 , 1) WITH NOWAIT 
                RETURN 1 
            END

            BEGIN TRY
                SET @created_time = SYSDATETIMEOFFSET()
                    EXEC @return_value = [internal].[insert_operation] 
                    200,
                    @created_time,
                    20,
                    NULL,
                    @project_name,
                    1,
                    null,
                    null,
                    @caller_sid,
                    @caller_name,
                    null,
                    null,
                    null,
                    @operation_id OUTPUT
                IF @return_value <> 0
                    RETURN 1;

                EXECUTE AS CALLER
                EXEC @return_value = [internal].[init_object_permissions] 4, @operation_id, @caller_id
                REVERT 
               
                IF @return_value <> 0
                BEGIN
                    RAISERROR(27153, 16, 1) WITH NOWAIT
                    RETURN 1
                END 
        
                SET @execution_id = @operation_id
 
            END TRY
            BEGIN CATCH
                UPDATE [internal].[operations] 
                    SET 
                    [end_time]  = SYSDATETIME(),
                    [status]    = 4
                    WHERE operation_id    = @operation_id;
                THROW;
            END CATCH

            DECLARE @sqlString              nvarchar(1024)
            DECLARE @key_name               [internal].[adt_name]
            DECLARE @certificate_name       [internal].[adt_name]
            DECLARE @encryption_algorithm   nvarchar(255)
    
            DECLARE @env_key_name               [internal].[adt_name]
            DECLARE @env_certificate_name       [internal].[adt_name]
    
            DECLARE @project_key_name               [internal].[adt_name]
            DECLARE @project_certificate_name       [internal].[adt_name]


            SET @encryption_algorithm = (SELECT [internal].[get_encryption_algorithm]())
    
            IF @encryption_algorithm IS NULL
            BEGIN
                RAISERROR(27156, 16, 1, ''''ENCRYPTION_ALGORITHM'''') WITH NOWAIT
            END

            SET TRANSACTION ISOLATION LEVEL SERIALIZABLE

            DECLARE @tran_count INT = @@TRANCOUNT;
            DECLARE @savepoint_name NCHAR(32);
            IF @tran_count > 0
            BEGIN
                SET @savepoint_name = REPLACE(CONVERT(NCHAR(36), NEWID()), N''''-'''', N'''''''');
                SAVE TRANSACTION @savepoint_name;
            END
            ELSE
                BEGIN TRANSACTION;
            BEGIN TRY
                --get an app lock to make sure the transaction is executed exclusively
                DECLARE @lock_result int
                EXEC @lock_result = sp_getapplock 
                    @Resource = ''''MS_ISServer_Create_Execution'''',
                    @LockTimeOut= 5000, -- 5 seconds
                    @LockMode = ''''Exclusive''''
                IF @lock_result < 0
                BEGIN
                    RAISERROR(27195, 16, 1) WITH NOWAIT  -- raise the timeout error
                END

                DECLARE @project_id bigint
                DECLARE @version_id bigint

                EXECUTE AS CALLER
                    SELECT @project_id = projs.[project_id],  
                        @version_id = projs.[object_version_lsn]
                        FROM [catalog].[projects] projs INNER JOIN [catalog].[folders] fds
                        ON projs.[folder_id] = fds.[folder_id] INNER JOIN [catalog].[packages] pkgs
                        ON projs.[project_id] = pkgs.[project_id] 
                        WHERE fds.[name] = @folder_name AND projs.[name] = @project_name
                        AND pkgs.[name] = @package_name
                REVERT
        
                IF (@project_id IS NULL)
                BEGIN
                    RAISERROR(27146, 16, 1) WITH NOWAIT
                END
        
        
                EXECUTE AS CALLER   
                SET @result =  [internal].[check_permission] 
                (
                    2,
                    @project_id,
                    3
                ) 
                REVERT
        
                IF @result = 0
                BEGIN
                    RAISERROR(27178, 16, 1, @project_name) WITH NOWAIT
                END

                DECLARE @environment_name nvarchar(128)
                DECLARE @environment_folder_name nvarchar(128)
                DECLARE @reference_type char(1)
        
                IF(@reference_id IS NOT NULL)
                BEGIN

                    EXECUTE AS CALLER
                        SELECT @environment_name = environment_name,
                            @environment_folder_name = environment_folder_name,
                            @reference_type = reference_type
                            FROM [catalog].[environment_references]
                            WHERE project_id = @project_id AND reference_id = @reference_id
                    REVERT
                    IF (@environment_name IS NULL)
                    BEGIN
                        RAISERROR(27208, 16, 1, @reference_id) WITH NOWAIT
                    END
            
            
                    SET @environment_found = 1
                    IF (@reference_type = ''''A'''')
                    BEGIN
                        SELECT @environment_id = envs.[environment_id]
                        FROM [internal].[folders] fds INNER JOIN [internal].[environments] envs
                        ON fds.[folder_id] = envs.[folder_id]
                        WHERE envs.[environment_name] = @environment_name AND fds.[name] = @environment_folder_name
                    END
                    ELSE IF (@reference_type = ''''R'''')
                    BEGIN
                        SELECT @environment_id = envs.[environment_id]
                            FROM  [internal].[projects] projs INNER JOIN [internal].[environments] envs
                            ON projs.[folder_id] = envs.[folder_id]
                            WHERE envs.[environment_name] = @environment_name AND projs.[project_id] = @project_id
                    END
                    IF (@environment_id IS NULL)
                    BEGIN
                        SET @environment_found = 0
                    END
            
                    EXECUTE AS CALLER
                        SET @result =  [internal].[check_permission]
                        (
                            3,
                            @environment_id,
                            1
                        )
                    REVERT
                    IF @result = 0
                    BEGIN
                        SET @environment_found = 0
                    END
                    IF @environment_found = 0
                    BEGIN
                        RAISERROR(27182 , 16 , 1, @environment_name) WITH NOWAIT
                    END
            
                    IF EXISTS 
                    (
                        SELECT params.[parameter_name]
                        FROM [internal].[environments] envs INNER JOIN [internal].[environment_variables] vars
                        ON envs.[environment_id] = vars.[environment_id] INNER JOIN [catalog].[object_parameters] params
                        ON vars.[name] = params.[referenced_variable_name] 
                        WHERE params.[value_type] = ''''R'''' AND params.[data_type] <> vars.[type] 
                        AND params.[project_id] = @project_id
                        AND (params.[object_type] = 20
                        OR (params.[object_name] = @package_name
                        AND params.[object_type] = 30))
                        AND envs.[environment_id] = @environment_id
                    )
                    BEGIN
                        RAISERROR(27148, 16, 1) WITH NOWAIT
                    END 
            
                    IF EXISTS 
                    (
                        SELECT params.[parameter_name]
                        FROM [internal].[environment_variables] vars INNER JOIN [catalog].[object_parameters] params
                        ON vars.[name] = params.[referenced_variable_name] 
                        WHERE params.[value_type] = ''''R'''' AND params.[data_type] = vars.[type] 
                        AND params.[sensitive] =0 AND vars.[sensitive] = 1
                        AND params.[project_id] = @project_id
                        AND (params.[object_type] = 20
                        OR (params.[object_name] = @package_name
                        AND params.[object_type] = 30))
                        AND vars.[environment_id] = @environment_id
                    )
                    BEGIN
                        RAISERROR(27221, 16, 1) WITH NOWAIT
                    END
                END
        
                UPDATE [internal].[operations]
                    SET [object_id] = @project_id
                    WHERE [operation_id] = @operation_id
                IF @@ROWCOUNT <> 1
                BEGIN
                    RAISERROR(27112, 16, 1, N''''operations'''') WITH NOWAIT
                END
        
                DECLARE @server_edition nvarchar(255)
                select @server_edition = Convert(nvarchar(255),SERVERPROPERTY(''''Edition''''))
                DECLARE @isServer64bit int
                select @isServer64bit = CHARINDEX(N''''64'''',@server_edition)

                IF @isServer64bit = 0
                BEGIN
                    SET @use32bitruntime = 1
                END
        
        
                INSERT into [internal].[executions]
                (
                    execution_id,
                    folder_name,
                    project_name,
                    package_name,
                    reference_id,
                    reference_type,
                    environment_folder_name,
                    environment_name,
                    project_lsn,
                    executed_as_sid,
                    executed_as_name,
                    use32bitruntime
                )
                VALUES (
                    @operation_id,
                    @folder_name,
                    @project_name,
                    @package_name,
                    @reference_id,
                    @reference_type,
                    @environment_folder_name,
                    @environment_name,
                    @version_id,
                    @caller_sid,
                    @caller_name,
                    @use32bitruntime
                )

                SET @key_name = ''''MS_Enckey_Exec_''''+CONVERT(varchar,@execution_id)
                SET @certificate_name = ''''MS_Cert_Exec_''''+CONVERT(varchar,@execution_id)

                SET @sqlString = ''''CREATE CERTIFICATE '''' + @certificate_name + '''' WITH SUBJECT = ''''''''ISServerCertificate''''''''''''

                IF  NOT EXISTS (SELECT [name] FROM [sys].[certificates] WHERE [name] = @certificate_name)
                EXECUTE sp_executesql @sqlString 

                SET @sqlString = ''''CREATE SYMMETRIC KEY '''' + @key_name +'''' WITH ALGORITHM = '''' 
                    + @encryption_algorithm + '''' ENCRYPTION BY CERTIFICATE '''' + @certificate_name

                IF  NOT EXISTS (SELECT [name] FROM [sys].[symmetric_keys] WHERE [name] = @key_name)
                EXECUTE sp_executesql @sqlString 

                SET @sqlString = ''''OPEN SYMMETRIC KEY '''' + @key_name 
                    + '''' DECRYPTION BY CERTIFICATE '''' + @certificate_name  
                EXECUTE sp_executesql @sqlString
                   
                IF @environment_id IS NOT NULL
                BEGIN
                    SET @env_key_name = ''''MS_Enckey_Env_''''+CONVERT(varchar,@environment_id)
                    SET @env_certificate_name = ''''MS_Cert_Env_''''+CONVERT(varchar,@environment_id)
            
                    SET @sqlString = ''''OPEN SYMMETRIC KEY '''' + @env_key_name 
                        + '''' DECRYPTION BY CERTIFICATE '''' + @env_certificate_name  
                    EXECUTE sp_executesql @sqlString        
                END
        
        
                SET @project_key_name = ''''MS_Enckey_Proj_''''+CONVERT(varchar,@project_id)
                SET @project_certificate_name = ''''MS_Cert_Proj_''''+CONVERT(varchar,@project_id)

                SET @sqlString = ''''OPEN SYMMETRIC KEY '''' + @project_key_name 
                    + '''' DECRYPTION BY CERTIFICATE '''' + @project_certificate_name  
                EXECUTE sp_executesql @sqlString  
            
                INSERT INTO [internal].[execution_parameter_values]
                (  
                    [execution_id], 
                    [object_type], 
                    [parameter_data_type], 
                    [parameter_name], 
                    [parameter_value],
                    [sensitive_parameter_value],
                    [base_data_type], 
                    [sensitive], 
                    [required], 
                    [value_set], 
                    [runtime_override]
                )
                SELECT  @execution_id, 
                    [object_type], 
                    [parameter_data_type], 
                    [parameter_name],
                    [default_value], 
                    NULL, 
                    [base_data_type],
                    [sensitive], 
                    [required], 
                    [value_set], 
                    0
                FROM [internal].[object_parameters] 
                    WHERE [project_id] = @project_id 
                    AND ([object_type] = 20 
                    OR ([object_name] = @package_name 
                    AND [object_type] = 30))
                    AND sensitive = 0 
                    AND [value_type] = ''''V'''' 
                    AND [project_version_lsn] = @version_id
             
                INSERT INTO [internal].[execution_parameter_values]
                (  
                    [execution_id], 
                    [object_type], 
                    [parameter_data_type], 
                    [parameter_name], 
                    [parameter_value],
                    [sensitive_parameter_value],
                    [base_data_type], 
                    [sensitive], 
                    [required], 
                    [value_set], 
                    [runtime_override]
                )
                SELECT  @execution_id, 
                    [object_type], 
                    [parameter_data_type], 
                    [parameter_name], 
                    NULL, 
                    ENCRYPTBYKEY(KEY_GUID(@key_name), DECRYPTBYKEY(sensitive_default_value)),
                    [base_data_type],
                    [sensitive], 
                    [required], 
                    [value_set], 
                    0
                FROM [internal].[object_parameters] 
                    WHERE [project_id] = @project_id 
                    AND ([object_type] = 20 
                    OR ([object_name] = @package_name 
                    AND [object_type] = 30))
                    AND sensitive = 1 
                    AND [value_type] = ''''V'''' 
                    AND [project_version_lsn] = @version_id    
        
                DECLARE @server_logging_level [NVARCHAR](256)

                SELECT @server_logging_level = [property_value] 
                FROM [internal].[catalog_properties]
                WHERE [property_name] = ''''SERVER_LOGGING_LEVEL'''' 
        
                DECLARE @bitfalse bit
                SET @bitfalse = 0
        
                INSERT INTO [internal].[execution_parameter_values]
                (
                    [execution_id], 
                    [object_type], 
                    [parameter_data_type], 
                    [parameter_name], 
                    [parameter_value],
                    [base_data_type],
                    [sensitive], 
                    [required], 
                    [value_set], 
                    [runtime_override]
                )
                VALUES 
                (
                    @execution_id,
                    50,
                    ''''Boolean'''',
                    ''''DUMP_ON_ERROR'''',
                    CONVERT(sql_variant,@bitfalse),
                    ''''bit'''',
                    0,
                    0,
                    1,
                    0
                ),
                (
                    @execution_id,
                    50,
                    ''''Boolean'''',
                    ''''DUMP_ON_EVENT'''',
                    CONVERT(sql_variant,@bitfalse),
                    ''''bit'''',
                    0,
                    0,
                    1,
                    0
                ),
                (
                    @execution_id,
                    50,
                    ''''String'''',
                    ''''DUMP_EVENT_CODE'''',
                    CONVERT(sql_variant,''''0''''),
                    ''''nvarchar'''',
                    0,
                    0,
                    1,
                    0
                ),
                (
                    @execution_id,
                    50,
                    ''''Int32'''',
                    ''''LOGGING_LEVEL'''',
                    CONVERT(sql_variant,CONVERT(INT,@server_logging_level)),
                    ''''int'''',
                    0,
                    0,
                    1,
                    0
                ),
                (
                    @execution_id,
                    50,
                    ''''String'''',
                    ''''CALLER_INFO'''',
                    null,
                    ''''nvarchar'''',
                    0,
                    0,
                    1,
                    0
                ),
                (
                    @execution_id,
                    50,
                    ''''Boolean'''',
                    ''''SYNCHRONIZED'''',
                    CONVERT(sql_variant,@bitfalse),
                    ''''bit'''',
                    0,
                    0,
                    1,
                    0
                )

                IF @environment_id IS NOT NULL
                BEGIN
                    INSERT INTO [internal].[execution_parameter_values]
                    (  
                        [execution_id], 
                        [object_type], 
                        [parameter_data_type], 
                        [parameter_name], 
                        [parameter_value],
                        [sensitive_parameter_value], 
                        [base_data_type],
                        [sensitive], 
                        [required], 
                        [value_set], 
                        [runtime_override]
                    )
                    SELECT  @execution_id, 
                        params.[object_type], 
                        params.[parameter_data_type], 
                        params.[parameter_name],
                        vars.[value], 
                        NULL, 
                        vars.[base_data_type],
                        params.[sensitive], 
                        params.[required], 
                        params.[value_set], 
                        0
                    FROM [internal].[object_parameters] params 
                        INNER JOIN [internal].[environment_variables] vars
                        ON params.[referenced_variable_name] = vars.[name] 
                        WHERE params.[project_id] = @project_id 
                        AND (params.[object_type] = 20
                        OR (params.[object_name] = @package_name 
                        AND params.[object_type] = 30))
                        AND vars.[sensitive] = 0 
                        AND params.[value_type] = ''''R'''' 
                        AND params.[project_version_lsn] = @version_id
                        AND vars.[environment_id] = @environment_id
            
                    INSERT INTO [internal].[execution_parameter_values]
                    (  
                        [execution_id], 
                        [object_type], 
                        [parameter_data_type], 
                        [parameter_name], 
                        [parameter_value],
                        [sensitive_parameter_value],
                        [base_data_type], 
                        [sensitive], 
                        [required], 
                        [value_set], 
                        [runtime_override]
                    )
                    SELECT  @execution_id, 
                        params.[object_type], 
                        params.[parameter_data_type], 
                        params.[parameter_name],
                        NULL, 
                        ENCRYPTBYKEY(KEY_GUID(@key_name), DECRYPTBYKEY(vars.[sensitive_value])), 
                        vars.[base_data_type],
                        vars.[sensitive], 
                        params.[required], 
                        params.[value_set], 
                        0
                    FROM [internal].[object_parameters] params 
                        INNER JOIN [internal].[environment_variables] vars
                        ON params.[referenced_variable_name] = vars.[name] 
                        WHERE params.[project_id] = @project_id 
                        AND (params.[object_type] = 20
                        OR (params.[object_name] = @package_name 
                        AND params.[object_type] = 30))
                        AND vars.[sensitive] = 1 
                        AND params.[value_type] = ''''R'''' 
                        AND params.[project_version_lsn] = @version_id
                        AND vars.[environment_id] = @environment_id
            
                    SET @sqlString = ''''CLOSE SYMMETRIC KEY ''''+ @env_key_name
                    EXECUTE sp_executesql @sqlString
                END
        
                UPDATE [internal].[execution_parameter_values]
                    SET [sensitive_parameter_value] = EncryptByKey(KEY_GUID(@key_name),CONVERT(varbinary(4000),CONVERT(datetime2,parameter_value))),
                    [parameter_value] = NULL
                    WHERE [execution_id] = @operation_id 
                    AND [sensitive] = 1 
                    AND [parameter_value] IS NOT NULL
                    AND [sensitive_parameter_value] IS NULL 
                    AND [parameter_data_type] = ''''datetime''''
        
                UPDATE [internal].[execution_parameter_values]
                    SET [sensitive_parameter_value] = EncryptByKey(KEY_GUID(@key_name),CONVERT(varbinary(4000),CONVERT(decimal(38,18),parameter_value))),
                    [parameter_value] = NULL
                    WHERE [execution_id] = @operation_id 
                    AND [sensitive] = 1 
                    AND [parameter_value] IS NOT NULL
                    AND [sensitive_parameter_value] IS NULL 
                    AND ([parameter_data_type] = ''''double'''' OR [parameter_data_type] = ''''single'''' OR [parameter_data_type] = ''''decimal'''')
        
                UPDATE [internal].[execution_parameter_values]
                    SET [sensitive_parameter_value] = EncryptByKey(KEY_GUID(@key_name),CONVERT(varbinary(4000),[parameter_value])),
                    [parameter_value] = NULL
                    WHERE [execution_id] = @operation_id 
                    AND [sensitive] = 1 
                    AND [parameter_value] IS NOT NULL
                    AND [sensitive_parameter_value] IS NULL 
                    AND [parameter_data_type] NOT IN (''''datetime'''', ''''double'''', ''''single'''', ''''decimal'''')  
        

                INSERT INTO [internal].[execution_parameter_values]
                (  
                    [execution_id], 
                    [object_type], 
                    [parameter_data_type], 
                    [parameter_name], 
                    [parameter_value],
                    [sensitive_parameter_value],
                    [base_data_type], 
                    [sensitive], 
                    [required], 
                    [value_set], 
                    [runtime_override]
                )
                SELECT  @execution_id,
                    objParams.[object_type], 
                    objParams.[parameter_data_type], 
                    objParams.[parameter_name],
                    NULL, 
                    NULL,
                    NULL, 
                    objParams.[sensitive], 
                    objParams.[required], 
                    0, 
                    0
                FROM 
                    (SELECT [object_type], 
                    [parameter_data_type], 
                    [parameter_name],
                    [sensitive], 
                    [required]
                FROM [internal].[object_parameters]
                    WHERE [project_id] = @project_id 
                    AND [object_type] = 20
                    AND [value_type] = ''''R'''' 
                    AND [project_version_lsn] = @version_id) objParams
                    LEFT JOIN
                    (SELECT [object_type],[parameter_name]
                    FROM [internal].[execution_parameter_values] 
                    WHERE [execution_id] = @operation_id) exeParams
                    ON objParams.[object_type] = exeParams.[object_type]
                    AND objParams.[parameter_name] = exeParams.[parameter_name] COLLATE SQL_Latin1_General_CP1_CS_AS
                    WHERE exeParams.[parameter_name] IS NULL
        
            
                    INSERT INTO [internal].[execution_parameter_values]
                    (  
                        [execution_id], 
                        [object_type], 
                        [parameter_data_type], 
                        [parameter_name], 
                        [parameter_value],
                        [sensitive_parameter_value],
                        [base_data_type], 
                        [sensitive], 
                        [required], 
                        [value_set], 
                        [runtime_override]
                    )
                    SELECT  @execution_id,
                        objParams.[object_type], 
                        objParams.[parameter_data_type], 
                        objParams.[parameter_name],
                        NULL, 
                        NULL,
                        NULL, 
                        objParams.[sensitive], 
                        objParams.[required], 
                        0, 
                        0
                    FROM 
                        (SELECT [object_type], 
                        [parameter_data_type], 
                        [parameter_name],
                        [sensitive], 
                        [required]
                        FROM [internal].[object_parameters]
                        WHERE [project_id] = @project_id 
                        AND [object_type] = 30
                        AND [value_type] = ''''R'''' 
                        AND [project_version_lsn] = @version_id
                        AND [object_name] = @package_name) objParams
                        LEFT JOIN
                        (SELECT [object_type],[parameter_name]
                        FROM [internal].[execution_parameter_values] 
                        WHERE [execution_id] = @operation_id) exeParams
                        ON objParams.[object_type] = exeParams.[object_type]
                        AND objParams.[parameter_name] = exeParams.[parameter_name] COLLATE SQL_Latin1_General_CP1_CS_AS
                        WHERE exeParams.[parameter_name] IS NULL;

                    WITH UnsetParameters AS
                    (
                        SELECT [execution_id],[object_type],[parameter_name],[parameter_value],[value_set]
                        FROM [internal].[execution_parameter_values] 
                        WHERE [sensitive] = 0 AND [required] = 0 AND [value_set] = 0
                        AND [execution_id] = @operation_id
                    )
                    UPDATE exeparams
                        SET [parameter_value] = objparams.[design_default_value]
                        FROM UnsetParameters AS exeparams INNER JOIN [internal].[object_parameters] objparams
                        ON exeparams.[parameter_name] = objparams.[parameter_name] COLLATE SQL_Latin1_General_CP1_CS_AS
                        AND exeparams.[object_type] = objparams.[object_type] 
                        AND exeparams.[value_set] = objparams.[value_set]
                        WHERE 
                        (objparams.[object_type] = 20 OR 
                        (objparams.[object_type] = 30 AND objparams.[object_name] = @package_name))
                        AND objparams.[project_id] = @project_id 
                        AND objparams.[project_version_lsn] = @version_id;

                    SET @sqlString = ''''CLOSE SYMMETRIC KEY ''''+ @key_name
                    EXECUTE sp_executesql @sqlString
        
                    SET @sqlString = ''''CLOSE SYMMETRIC KEY ''''+ @project_key_name
                    EXECUTE sp_executesql @sqlString

                    IF @tran_count = 0
                        COMMIT TRANSACTION;
                END TRY
                BEGIN CATCH
                    IF @tran_count = 0 
                        ROLLBACK TRANSACTION;
                    ELSE IF XACT_STATE() <> -1
                        ROLLBACK TRANSACTION @savepoint_name;

                    UPDATE [internal].[operations] SET 
                        [end_time]  = SYSDATETIMEOFFSET(),
                        [status]    = 4
                        WHERE operation_id    = @operation_id;
                    THROW;
                END CATCH
            RETURN 0 '

            SET @cmd = N'EXEC SSISDB.dbo.sp_executesql @statement=N''' + @rawCmd + ''''
            EXEC sp_executesql @cmd
            PRINT 'Stored procedure [catalog].[create_execution] has been recreated.'
        END

        IF OBJECT_ID (N'SSISDB.[catalog].[set_execution_parameter_value]', N'P') IS NULL
        BEGIN
            SET @rawCmd = N'
            CREATE PROCEDURE [catalog].[set_execution_parameter_value]
                @execution_id       bigint,   -- id of the execution
                @object_type        smallint, -- type of the object package/project
                @parameter_name     nvarchar(128), -- the name of the parameter
                @parameter_value    sql_variant -- the value of the parameter
            WITH EXECUTE AS ''''AllSchemaOwner''''
            AS 
                SET NOCOUNT ON

                DECLARE @caller_id     int
                DECLARE @caller_name   [internal].[adt_sname]
                DECLARE @caller_sid    [internal].[adt_sid]
                DECLARE @suser_name    [internal].[adt_sname]
                DECLARE @suser_sid     [internal].[adt_sid]

                EXECUTE AS CALLER\
                EXEC [internal].[get_user_info]
                    @caller_name OUTPUT,
                    @caller_sid OUTPUT,
                    @suser_name OUTPUT,
                    @suser_sid OUTPUT,
                    @caller_id OUTPUT;
                IF(
                    EXISTS(SELECT [name]
                    FROM sys.server_principals
                    WHERE [sid] = @suser_sid AND [type] = ''''S'''') 
                    OR
                    EXISTS(SELECT [name]
                    FROM sys.database_principals
                    WHERE ([sid] = @caller_sid AND [type] = ''''S'''')) 
                )
                BEGIN
                    RAISERROR(27123, 16, 1) WITH NOWAIT
                    RETURN 1
                END
                REVERT
                IF(
                    EXISTS(SELECT [name]
                    FROM sys.server_principals           
                    WHERE [sid] = @suser_sid AND [type] = ''''S'''')  
                    OR                                                 
                    EXISTS(SELECT [name]                              
                    FROM sys.database_principals             
                    WHERE ([sid] = @caller_sid AND [type] = ''''S'''')) 
                )
                BEGIN
                    RAISERROR(27123, 16, 1) WITH NOWAIT
                    RETURN 1
                END

                DECLARE @result int
                DECLARE @execution_parameter_id bigint
                DECLARE @sensitive bit
                DECLARE @data_type  nvarchar(128)
                DECLARE @value varbinary(MAX)
                DECLARE @parameter_type nvarchar(128)
                DECLARE @return_value           bit = 1

                IF (@execution_id IS NULL OR @object_type IS NULL 
                    OR @parameter_name IS NULL OR @parameter_value IS NULL)
                BEGIN
                    RAISERROR(27138, 16 , 1) WITH NOWAIT 
                    RETURN 1 
                END

                IF (@object_type NOT IN(20, 30, 50))
                BEGIN
                    RAISERROR(27101, 16 , 1, N''''object type'''') WITH NOWAIT
                    RETURN 1;
                END

                IF @execution_id <= 0
                BEGIN
                    RAISERROR(27101, 16 , 1, N''''execution_id'''') WITH NOWAIT
                    RETURN 1;
                END

                SET @parameter_type = CONVERT(nvarchar(128), SQL_VARIANT_PROPERTY(@parameter_value, ''''BaseType''''));

                DECLARE @sqlString              nvarchar(1024)
                DECLARE @key_name               [internal].[adt_name]
                DECLARE @certificate_name       [internal].[adt_name]
                DECLARE @encryption_algorithm   nvarchar(255)    

                SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
                DECLARE @tran_count INT = @@TRANCOUNT;
                DECLARE @savepoint_name NCHAR(32);
                IF @tran_count > 0
                BEGIN
                    SET @savepoint_name = REPLACE(CONVERT(NCHAR(36), NEWID()), N''''-'''', N'''''''');
                    SAVE TRANSACTION @savepoint_name;
                END
                ELSE
                    BEGIN TRANSACTION;

                BEGIN TRY 
                    EXECUTE AS CALLER   
                    SET @result = [internal].[check_permission] 
                    (
                        4,
                        @execution_id,
                        2
                    ) 
                    REVERT

                    IF @result = 0
                    BEGIN
                        RAISERROR(27103 , 16 , 1, @execution_id) WITH NOWAIT
                    END  

                    DECLARE @project_id bigint
                    DECLARE @status int
                    EXECUTE AS CALLER
                    SELECT @project_id = [object_id], @status = [status]
                        FROM [catalog].[operations]
                        WHERE [operation_id] = @execution_id 
                        AND [object_type] = 20
                        AND [operation_type] = 200
                    REVERT

                    IF (@project_id IS NULL)
                    BEGIN
                        RAISERROR(27103 , 16 , 1, @execution_id) WITH NOWAIT
                    END

                    IF  @status <> 1
                    BEGIN
                        RAISERROR(27224, 16 , 1) WITH NOWAIT
                    END

                    SELECT @execution_parameter_id = [execution_parameter_id],
                        @sensitive = [sensitive],
                        @data_type = [parameter_data_type]
                        FROM   [internal].[execution_parameter_values]
                        WHERE  [execution_id] = @execution_id AND [object_type] = @object_type 
                        AND [parameter_name] = @parameter_name COLLATE SQL_Latin1_General_CP1_CS_AS

                    IF @execution_parameter_id IS NULL 
                    BEGIN
                        RAISERROR(27176 , 16 , 1, @parameter_name) WITH NOWAIT
                    END
                    ELSE IF @sensitive IS NULL OR @data_type IS NULL
                    BEGIN
                        RAISERROR(27205, 16 , 1) WITH NOWAIT
                    END

                    IF NOT EXISTS (SELECT [ssis_data_type] FROM [internal].[data_type_mapping]
                        WHERE [ssis_data_type] = @data_type)
                    BEGIN
                        RAISERROR(27159, 16 , 1) WITH NOWAIT
                    END

                    EXEC @return_value = [internal].[check_data_type_value] 
                    @parameter_value, @data_type

                    IF (@return_value <> 0)
                    --check value FAILED, the error is already been handled. The following code should not happen
                    BEGIN
                        RAISERROR(27147, 16 , 1, @data_type) WITH NOWAIT
                    END 

                    EXEC @return_value = [internal].[check_parameter_value_by_name] 
                    @parameter_value, @parameter_name

                    IF (@return_value <> 0)
                    --check value FAILED, the error is already been handled. The following code should not happen
                    BEGIN
                        RETURN 1
                    END 

                    IF @sensitive = 1
                    BEGIN
                        SET @key_name = ''''MS_Enckey_Exec_''''+CONVERT(varchar,@execution_id)
                        SET @certificate_name = ''''MS_Cert_Exec_''''+CONVERT(varchar,@execution_id) 

                        SET @sqlString = ''''OPEN SYMMETRIC KEY '''' + @key_name 
                            + '''' DECRYPTION BY CERTIFICATE '''' + @certificate_name  
                        EXECUTE sp_executesql @sqlString

                        IF @data_type = ''''datetime''''
                        BEGIN
                            SET @value = EncryptByKey(KEY_GUID(@key_name),CONVERT(varbinary(4000),CONVERT(datetime2,@parameter_value)))
                        END
                        ELSE IF @data_type = ''''single'''' OR @data_type = ''''double'''' OR @data_type = ''''decimal''''
                        BEGIN
                            SET @value = EncryptByKey(KEY_GUID(@key_name),CONVERT(varbinary(4000),CONVERT(decimal(38,18),@parameter_value)))
                        END 
                        ELSE
                        BEGIN
                            SET @value = EncryptByKey(KEY_GUID(@key_name),CONVERT(varbinary(4000),@parameter_value))   
                        END

                        SET @sqlString = ''''CLOSE SYMMETRIC KEY ''''+ @key_name
                        EXECUTE sp_executesql @sqlString  

                        UPDATE [internal].[execution_parameter_values]
                            SET [runtime_override] = 1,
                            [value_set] = 1,
                            [base_data_type] = @parameter_type,
                            [sensitive_parameter_value] = @value
                            WHERE [execution_parameter_id] = @execution_parameter_id
                    END
                ELSE
                BEGIN
                    UPDATE [internal].[execution_parameter_values]
                        SET [runtime_override] = 1,
                        [value_set] = 1,
                        [base_data_type] = @parameter_type,
                        [parameter_value] = @parameter_value
                        WHERE [execution_parameter_id] = @execution_parameter_id
                END

                IF @tran_count = 0
                    COMMIT TRANSACTION;
            END TRY
            BEGIN CATCH
                IF @tran_count = 0
                    ROLLBACK TRANSACTION;
                ELSE IF XACT_STATE() <> -1
                    ROLLBACK TRANSACTION @savepoint_name;

                THROW;
            END CATCH
        RETURN 0
        '
            SET @cmd = N'EXEC SSISDB.dbo.sp_executesql @statement=N''' + @rawCmd + ''''
            EXEC sp_executesql @cmd
            PRINT 'Stored procedure [catalog].[set_execution_parameter_value] has been recreated.'
        END

        IF OBJECT_ID (N'SSISDB.[catalog].[configure_catalog]', N'P') IS NULL
        BEGIN
            SET @rawCmd = N'
                CREATE PROCEDURE [catalog].[configure_catalog] 
                @property_name           nvarchar(255), 
                @property_value          nvarchar(255)
            AS
            BEGIN
                SET NOCOUNT ON

                --These variables are declared within this macro: @caller_id, @caller_name, @caller_sid, @suser_name, @suser_sid
                DECLARE @caller_id     int
                DECLARE @caller_name   [internal].[adt_sname]
                DECLARE @caller_sid    [internal].[adt_sid]
                DECLARE @suser_name    [internal].[adt_sname]
                DECLARE @suser_sid     [internal].[adt_sid]

                EXECUTE AS CALLER
                    EXEC [internal].[get_user_info]
                    @caller_name OUTPUT,
                    @caller_sid OUTPUT,
                    @suser_name OUTPUT,
                    @suser_sid OUTPUT,
                    @caller_id OUTPUT;
                IF(
                    EXISTS(SELECT [name]
                    FROM sys.server_principals
                    WHERE [sid] = @suser_sid AND [type] = ''''S'''')
                    OR
                    EXISTS(SELECT [name]
                    FROM sys.database_principals
                    WHERE ([sid] = @caller_sid AND [type] = ''''S'''')) 
                )
                BEGIN
                    RAISERROR(27123, 16, 1) WITH NOWAIT
                    RETURN 1
                END
                REVERT
                IF(
                    EXISTS(SELECT [name]
                    FROM sys.server_principals
                    WHERE [sid] = @suser_sid AND [type] = ''''S'''') 
                    OR
                    EXISTS(SELECT [name]
                    FROM sys.database_principals
                    WHERE ([sid] = @caller_sid AND [type] = ''''S'''')) 
                )
                BEGIN
                    RAISERROR(27123, 16, 1) WITH NOWAIT
                    RETURN 1
                END

                EXECUTE AS CALLER
                    IF ((IS_MEMBER(''''ssis_admin'''') <> 1) AND (IS_SRVROLEMEMBER(''''sysadmin'''') <> 1))
                    BEGIN
                        RAISERROR(27140, 16, 1, N''''ssis_admin'''', N''''sysadmin'''') WITH NOWAIT
                        RETURN 1 
                    END
                REVERT

                IF @property_name IS NULL OR @property_value IS NULL
                BEGIN
                    RAISERROR(27138, 16 , 6) WITH NOWAIT 
                    RETURN 1 
                END

                IF @property_name NOT IN (''''ENCRYPTION_ALGORITHM'''', ''''RETENTION_WINDOW'''', 
                    ''''MAX_PROJECT_VERSIONS'''', ''''VERSION_CLEANUP_ENABLED'''', ''''OPERATION_CLEANUP_ENABLED'''', ''''SERVER_LOGGING_LEVEL'''',''''SERVER_LOGGING_LEVEL'''')
                BEGIN
                    RAISERROR(27101, 16 , 1, N''''property_name'''') WITH NOWAIT
                    RETURN 1
                END

                DECLARE @operation_id       bigint
                DECLARE @return_value       int
                DECLARE @status             int
                DECLARE @result             bit
                DECLARE @ret                int
                DECLARE @old_algorithm_name nvarchar(255)

                SET @result = 1

                INSERT INTO [internal].[operations] (
                    [operation_type],
                    [created_time],
                    [object_type],
                    [object_id],
                    [object_name] ,
                    [status], 
                    [start_time],
                    [caller_sid], 
                    [caller_name]
                )
                VALUES (
                    1000,
                    SYSDATETIMEOFFSET(),
                    NULL,
                    NULL,
                    @property_name,
                    2,
                    SYSDATETIMEOFFSET(), 
                    @caller_sid,
                    @caller_name
                )

                IF @@ROWCOUNT <> 1
                BEGIN
                RETURN 1;
                END

                SET @operation_id = SCOPE_IDENTITY();

                EXECUTE AS CALLER
                EXEC @return_value = [internal].[init_object_permissions] 
                    4, @operation_id, @caller_id 
                REVERT
                IF @return_value <> 0
                BEGIN
                -- This should not happen
                    RAISERROR(27153, 16, 1) WITH NOWAIT
                    RETURN 1
                END

                /*Change the encryption algorithm*/
                IF (UPPER(@property_name) = ''''ENCRYPTION_ALGORITHM'''')
                BEGIN
                    /*Check whether the database is in single user mode*/
                    SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
                    DECLARE @tran_count INT = @@TRANCOUNT;
                    DECLARE @savepoint_name NCHAR(32);
                    IF @tran_count > 0
                    BEGIN
                        SET @savepoint_name = REPLACE(CONVERT(NCHAR(36), NEWID()), N''''-'''', N''''''''); 
                        SAVE TRANSACTION @savepoint_name;
                    END
                    ELSE
                        BEGIN TRANSACTION;
                    
                    BEGIN TRY

                        IF NOT EXISTS (SELECT [user_access] FROM sys.databases 
                            WHERE name = ''''SSISDB'''' and [user_access] = 1 )
                        BEGIN
                            RAISERROR(27162, 16 , 1, N''''ENCRYPTION_ALGORITHM'''' ) WITH NOWAIT
                        END

                        SELECT @old_algorithm_name = property_value
                            FROM [internal].[catalog_properties] 
                            WHERE property_name = ''''ENCRYPTION_ALGORITHM''''

                        SELECT @ret = [internal].[validate_encryption_algorithm](@property_value)
                        IF @ret <> 0
                        BEGIN
                            RAISERROR(27101, 16, 12, N''''property_value'''') WITH NOWAIT
                        END

                        /*Invoke the internal stored procedureS to change the encryption algorithm*/
                        EXEC @ret = [internal].[configure_environment_encryption_algorithm] @property_value, @operation_id
                        IF @ret <> 0
                        BEGIN
                            RAISERROR (27167, 16, 1, @property_value,@property_value ) WITH NOWAIT
                        END

                        EXEC @ret = [internal].[configure_execution_encryption_algorithm] @property_value, @operation_id
                        IF @ret <> 0
                        BEGIN
                            RAISERROR (27168,16,1, @property_value,@property_value) WITH NOWAIT
                        END

                        EXEC @ret = [internal].[configure_project_encryption_algorithm] @property_value,@old_algorithm_name, @operation_id
                        IF @ret <> 0
                        BEGIN
                            RAISERROR (27168,16,1, @property_value,@property_value) WITH NOWAIT
                        END

                        -- update the algorithm value in catalog_properties table
                        UPDATE [internal].[catalog_properties] 
                            SET property_value = @property_value
                            WHERE property_name = ''''ENCRYPTION_ALGORITHM''''
                        IF @tran_count = 0
                            COMMIT TRANSACTION;
                    END TRY
                    BEGIN CATCH 
                        IF @tran_count = 0 
                            ROLLBACK TRANSACTION;
                        ELSE IF XACT_STATE() <> -1
                            ROLLBACK TRANSACTION @savepoint_name;
                        UPDATE [internal].[operations] SET 
                            [end_time]  = SYSDATETIMEOFFSET(),
                            [status]    = 4
                            WHERE operation_id    = @operation_id;
                        THROW;
                    END CATCH
                END
                ELSE IF (UPPER(@property_name) = ''''RETENTION_WINDOW'''')
                BEGIN
                    --Check input
                    BEGIN TRY
                        DECLARE @retention_window INT
                        SET @retention_window = CONVERT(INT, @property_value)
                        --retention_window should be -1 or a positive integer and it shall be less than 10 years
                        IF @retention_window <= 0 OR @retention_window >3650
                            BEGIN
                            RAISERROR(27101, 16, 14, N''''property_value'''') WITH NOWAIT
                        END

                        UPDATE [internal].[catalog_properties] 
                        SET property_value = @property_value
                        WHERE property_name = ''''RETENTION_WINDOW''''

                        IF @@ROWCOUNT <> 1
                        BEGIN
                            RAISERROR(27112, 16, 8, N''''isserver_property'''') WITH NOWAIT;
                        END
                    END TRY
                    BEGIN CATCH
                        UPDATE [internal].[operations] SET 
                            [end_time]  = SYSDATETIMEOFFSET(),
                            [status]    = 4
                            WHERE operation_id    = @operation_id;  
                        THROW;
                    END CATCH
                END
                ELSE IF (UPPER(@property_name) = ''''MAX_PROJECT_VERSIONS'''')
                BEGIN
                    --Check input
                    BEGIN TRY
                        DECLARE @version_count INT
                        SET @version_count = CONVERT(INT, @property_value)

                        IF @version_count <= 0 OR @version_count > 9999
                        BEGIN
                            RAISERROR(27101, 16, 16, N''''property_value'''') WITH NOWAIT
                        END

                        UPDATE [internal].[catalog_properties] 
                        SET property_value = @property_value
                        WHERE property_name = ''''MAX_PROJECT_VERSIONS''''

                        IF @@ROWCOUNT <> 1
                        BEGIN
                            RAISERROR(27112, 16, 9, N''''isserver_property'''') WITH NOWAIT;
                        END
                    END TRY

                    BEGIN CATCH
                        UPDATE [internal].[operations] SET 
                            [end_time]  = SYSDATETIMEOFFSET(),
                            [status]    = 4
                            WHERE operation_id    = @operation_id;
                        THROW;
                    END CATCH
                END
                ELSE IF (UPPER(@property_name) = ''''OPERATION_CLEANUP_ENABLED'''')
                BEGIN
                    --Check input
                    BEGIN TRY

                        IF @property_value NOT IN (''''TRUE'''', ''''FALSE'''')
                        BEGIN
                            RAISERROR(27101, 16, 16, N''''property_value'''') WITH NOWAIT
                        END

                        UPDATE [internal].[catalog_properties] 
                            SET property_value = @property_value
                            WHERE property_name = ''''OPERATION_CLEANUP_ENABLED''''

                        IF @@ROWCOUNT <> 1
                        BEGIN
                            RAISERROR(27112, 16, 9, N''''isserver_property'''') WITH NOWAIT;
                        END
                    END TRY

                    BEGIN CATCH
                        UPDATE [internal].[operations] SET 
                            [end_time]  = SYSDATETIMEOFFSET(),
                            [status]    = 4
                            WHERE operation_id    = @operation_id;
                        THROW;
                    END CATCH
                END
                ELSE IF (UPPER(@property_name) = ''''VERSION_CLEANUP_ENABLED'''')
                BEGIN
                --Check input
                BEGIN TRY

                    IF @property_value NOT IN (''''TRUE'''', ''''FALSE'''')
                    BEGIN
                        RAISERROR(27101, 16, 16, N''''property_value'''') WITH NOWAIT
                    END

                    UPDATE [internal].[catalog_properties] 
                        SET property_value = @property_value
                        WHERE property_name = ''''VERSION_CLEANUP_ENABLED''''

                    IF @@ROWCOUNT <> 1
                    BEGIN
                        RAISERROR(27112, 16, 9, N''''isserver_property'''') WITH NOWAIT;
                    END
                END TRY

                BEGIN CATCH
                    UPDATE [internal].[operations] SET 
                        [end_time]  = SYSDATETIMEOFFSET(),
                        [status]    = 4
                        WHERE operation_id    = @operation_id;
                    THROW;
                END CATCH
                END
                ELSE IF (UPPER(@property_name) = ''''SERVER_LOGGING_LEVEL'''')
                BEGIN
                    --Check input
                    BEGIN TRY
                        DECLARE @server_logging_level INT
                        SET @server_logging_level = CONVERT(INT, @property_value)
                        IF (@server_logging_level < 0 OR @server_logging_level > 3)
                        BEGIN
                            RAISERROR(27217, 16 , 1, @server_logging_level) WITH NOWAIT
                        END

                        UPDATE [internal].[catalog_properties] 
                            SET property_value = @property_value
                            WHERE property_name = ''''SERVER_LOGGING_LEVEL''''

                        IF @@ROWCOUNT <> 1
                        BEGIN
                            RAISERROR(27112, 16, 8, N''''isserver_property'''') WITH NOWAIT;
                        END
                    END TRY
                    BEGIN CATCH
                        UPDATE [internal].[operations] SET 
                            [end_time]  = SYSDATETIMEOFFSET(),
                            [status]    = 4
                            WHERE operation_id    = @operation_id;  
                        THROW;
                    END CATCH
                END
                ELSE
                BEGIN
                    -- should not happen
                    RAISERROR(27101, 16, 13, N''''property_name'''') WITH NOWAIT
                    RETURN 1
                END

                UPDATE [internal].[operations] SET 
                    [end_time]  = SYSDATETIMEOFFSET(),
                    [status]    = 7
                    WHERE operation_id    = @operation_id 
                RETURN 0
            END
            '
            SET @cmd = N'EXEC SSISDB.dbo.sp_executesql @statement=N''' + @rawCmd + ''''
            EXEC sp_executesql @cmd
            PRINT 'Stored procedure [catalog].[configure_catalog] has been recreated.'
        END


        IF OBJECT_ID (N'SSISDB.[internal].[cleanup_server_retention_window]', N'P') IS NULL
        BEGIN
            SET @rawCmd = N'
            CREATE PROCEDURE [internal].[cleanup_server_retention_window]
            WITH EXECUTE AS ''''AllSchemaOwner''''
            AS
                SET NOCOUNT ON

                DECLARE @enable_clean_operation bit
                DECLARE @retention_window_length int

                DECLARE @caller_name nvarchar(256)
                DECLARE @caller_sid  varbinary(85)
                DECLARE @operation_id bigint

                EXECUTE AS CALLER
                SET @caller_name =  SUSER_NAME()
                SET @caller_sid =   SUSER_SID()
                REVERT
 
                -- delete operations based on the retension window size 
                BEGIN TRY
                    SELECT @enable_clean_operation = CONVERT(bit, property_value) 
                        FROM [catalog].[catalog_properties]
                        WHERE property_name = ''''OPERATION_CLEANUP_ENABLED''''

                    IF @enable_clean_operation = 1
                    BEGIN
                        SELECT @retention_window_length = CONVERT(int,property_value)  
                            FROM [catalog].[catalog_properties]
                            WHERE property_name = ''''RETENTION_WINDOW''''

                        IF @retention_window_length <= 0 --a negative number is not valid
                        BEGIN
                            RAISERROR(27163,16,1,''''RETENTION_WINDOW'''')
                        END

                        INSERT INTO [internal].[operations] (
                            [operation_type],  
                            [created_time], 
                            [object_type],
                            [object_id],
                            [object_name],
                            [status], 
                            [start_time],
                            [caller_sid], 
                            [caller_name]
                        )
                        VALUES (
                            2,
                            SYSDATETIMEOFFSET(),
                            NULL,                     -- No object type for this operation
                            NULL,                     -- The project_id is not set  
                            NULL,                     -- The object name is not set
                            1,      
                            SYSDATETIMEOFFSET(),
                            @caller_sid,            -- SID of the user 
                            @caller_name            -- Name of the database principal.
                        ) 
                        SET @operation_id = SCOPE_IDENTITY() 

                        DECLARE @temp_date datetime
                        DECLARE @rows_affected bigint
                        DECLARE @delete_batch_size int
                        DECLARE @deleted_ops TABLE(operation_id bigint, operation_type smallint)

                        -- every time, we would delete 10 operations per batch
                        SET @delete_batch_size = 10  
                        SET @rows_affected = @delete_batch_size

                        SET @temp_date = GETDATE() - @retention_window_length

                        WHILE (@rows_affected = @delete_batch_size)
                        BEGIN
                            DELETE TOP (@delete_batch_size)
                            FROM [internal].[operations] 
                                OUTPUT DELETED.operation_id, DELETED.operation_type INTO @deleted_ops
                                WHERE ( [end_time] <= @temp_date
                                -- A special case when END_TIME is null, we will delete the records based on the created time 
                                OR ([end_time] IS NULL AND [status] = 1 AND [created_time] <= @temp_date ))

                            SET @rows_affected = @@ROWCOUNT
                        END

                        DECLARE @execution_id bigint
                        DECLARE @sqlString              nvarchar(1024)
                        DECLARE @key_name               [internal].[adt_name]
                        DECLARE @certificate_name       [internal].[adt_name]

                        -- Drop the key and certificate for execution
                        DECLARE execution_cursor CURSOR LOCAL FOR 
                            SELECT operation_id FROM @deleted_ops 
                            WHERE operation_type = 200

                        OPEN execution_cursor
                        FETCH NEXT FROM execution_cursor INTO @execution_id

                        WHILE @@FETCH_STATUS = 0
                        BEGIN
                            SET @key_name = ''''MS_Enckey_Exec_''''+CONVERT(varchar,@execution_id)
                            SET @certificate_name = ''''MS_Cert_Exec_''''+CONVERT(varchar,@execution_id)
                            SET @sqlString = ''''DROP SYMMETRIC KEY ''''+ @key_name
                            IF EXISTS (SELECT name FROM sys.symmetric_keys WHERE name = @key_name)
                                EXECUTE sp_executesql @sqlString

                            SET @sqlString = ''''DROP CERTIFICATE '''' + @certificate_name
                            IF EXISTS (select name from sys.certificates WHERE name = @certificate_name)
                            EXECUTE sp_executesql @sqlString

                            FETCH NEXT FROM execution_cursor INTO @execution_id
                        END
                        CLOSE execution_cursor
                        DEALLOCATE execution_cursor

                        UPDATE [internal].[operations]
                            SET [status] = 7,
                            [end_time] = SYSDATETIMEOFFSET()
                            WHERE [operation_id] = @operation_id
                    END
                    END TRY
                    BEGIN CATCH

                        -- If the cursor is still open, close it
                        IF (CURSOR_STATUS(''''local'''', ''''execution_cursor'''') = 1 
                            OR CURSOR_STATUS(''''local'''', ''''execution_cursor'''') = 0)
                        BEGIN
                            CLOSE execution_cursor
                            DEALLOCATE execution_cursor
                        END

                        UPDATE [internal].[operations]
                            SET [status] = 4,
                            [end_time] = SYSDATETIMEOFFSET()
                            WHERE [operation_id] = @operation_id;
                        THROW
                    END CATCH
                RETURN 0
            '
            SET @cmd = N'EXEC SSISDB.dbo.sp_executesql @statement=N''' + @rawCmd + ''''
            EXEC sp_executesql @cmd
            PRINT 'Stored procedure [internal].[cleanup_server_retention_window] has been recreated.'
        END

        IF OBJECT_ID (N'SSISDB.[internal].[get_execution_values]', N'P') IS NULL
        BEGIN
            SET @rawCmd = N'
            CREATE PROCEDURE [internal].[get_execution_values]
                    @execution_id       bigint         -- id of the execution
            WITH EXECUTE AS ''''AllSchemaOwner''''
            AS 
                SET NOCOUNT ON
                DECLARE @result int

                DECLARE @sqlString              nvarchar(1024)
                DECLARE @key_name               [internal].[adt_name]
                DECLARE @certificate_name       [internal].[adt_name]
                DECLARE @encryption_algorithm   nvarchar(255)

                IF (@execution_id IS NULL)
                BEGIN
                    RAISERROR(27138, 16 , 1) WITH NOWAIT 
                    RETURN 1 
                END   

                IF @execution_id <= 0
                BEGIN
                    RAISERROR(27101, 16 , 1, N''''execution_id'''') WITH NOWAIT
                    RETURN 1;
                END

                EXECUTE AS CALLER   
                    SET @result = [internal].[check_permission] 
                    (
                        4,
                        @execution_id,
                        2
                    ) 
                REVERT

                IF @result = 0
                BEGIN
                    RAISERROR(27103, 16 , 1, @execution_id) WITH NOWAIT
                    RETURN 1
                END  

                IF NOT EXISTS (SELECT [operation_id] FROM [internal].[operations] 
                    WHERE [operation_id]= @execution_id AND [status] = 5
                    AND [operation_type] = 200)
                BEGIN
                    RAISERROR(27103, 16 , 1, @execution_id) WITH NOWAIT
                    RETURN 1
                END  

                SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
                DECLARE @tran_count INT = @@TRANCOUNT;
                DECLARE @savepoint_name NCHAR(32);
                IF @tran_count > 0
                BEGIN
                    SET @savepoint_name = REPLACE(CONVERT(NCHAR(36), NEWID()), N''''-'''', N'''''''');
                    SAVE TRANSACTION @savepoint_name;
                END
                ELSE
                    BEGIN TRANSACTION;

                BEGIN TRY 

                    SET @key_name = ''''MS_Enckey_Exec_''''+CONVERT(varchar,@execution_id)
                    SET @certificate_name = ''''MS_Cert_Exec_''''+CONVERT(varchar,@execution_id) 

                    SET @sqlString = ''''OPEN SYMMETRIC KEY '''' + @key_name 
                        + '''' DECRYPTION BY CERTIFICATE '''' + @certificate_name  
                    EXECUTE sp_executesql @sqlString

                    SELECT [execution_id],
                        [object_type],
                        [parameter_data_type],
                        [parameter_name],
                        [parameter_value] AS value,
                        [sensitive],
                        [required],
                        [runtime_override]
                    FROM internal.[execution_parameter_values]
                    WHERE [execution_id] = @execution_id 
                        AND [sensitive] = 0
                        AND [value_set] = 1
                    UNION
                    SELECT [execution_id],
                        [object_type],
                        [parameter_data_type],
                        [parameter_name],
                        [internal].[get_value_by_data_type](DECRYPTBYKEY([sensitive_parameter_value]),[parameter_data_type]) AS value,
                        [sensitive],
                        [required],
                        [runtime_override]
                    FROM internal.[execution_parameter_values]
                    WHERE [execution_id] = @execution_id 
                        AND [sensitive] = 1
                        AND [value_set] = 1
 
                    SET @sqlString = ''''CLOSE SYMMETRIC KEY ''''+ @key_name
                    EXECUTE sp_executesql @sqlString             
                    IF @tran_count = 0
                        COMMIT TRANSACTION;
                END TRY
                BEGIN CATCH
                    IF @tran_count = 0 
                        ROLLBACK TRANSACTION;
                    ELSE IF XACT_STATE() <> -1
                        ROLLBACK TRANSACTION @savepoint_name;

                    SET @sqlString = ''''CLOSE SYMMETRIC KEY ''''+ @key_name
                    IF EXISTS (SELECT key_name FROM sys.openkeys WHERE key_name =  @key_name)
                        EXECUTE sp_executesql @sqlString;
                    THROW;
               END CATCH
               RETURN 0
            '
            SET @cmd = N'EXEC SSISDB.dbo.sp_executesql @statement=N''' + @rawCmd + ''''
            EXEC sp_executesql @cmd
            PRINT 'Stored procedure [internal].[get_execution_values] has been recreated.'
        END

        IF OBJECT_ID (N'SSISDB.[internal].[get_execution_property_override_values]', N'P') IS NULL
        BEGIN
            SET @rawCmd = N'
            CREATE PROCEDURE [internal].[get_execution_property_override_values]
                @execution_id       bigint         -- id of the execution
            WITH EXECUTE AS ''''AllSchemaOwner''''
            AS 
                SET NOCOUNT ON
                DECLARE @result int

                DECLARE @sqlString              nvarchar(1024)
                DECLARE @key_name               [internal].[adt_name]
                DECLARE @certificate_name       [internal].[adt_name]
                DECLARE @encryption_algorithm   nvarchar(255)

                IF (@execution_id IS NULL)
                BEGIN
                    RAISERROR(27138, 16 , 1) WITH NOWAIT 
                    RETURN 1 
                END   

                IF @execution_id <= 0
                BEGIN
                    RAISERROR(27101, 16 , 1, N''''execution_id'''') WITH NOWAIT
                    RETURN 1;
                END

                EXECUTE AS CALLER   
                SET @result = [internal].[check_permission] 
                (
                    4,
                    @execution_id,
                    2
                ) 
                REVERT

                IF @result = 0
                BEGIN
                    RAISERROR(27103, 16 , 1, @execution_id) WITH NOWAIT
                    RETURN
                END

                SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
                DECLARE @tran_count INT = @@TRANCOUNT;
                DECLARE @savepoint_name NCHAR(32);
                IF @tran_count > 0
                BEGIN
                    SET @savepoint_name = REPLACE(CONVERT(NCHAR(36), NEWID()), N''''-'''', N'''''''');
                    SAVE TRANSACTION @savepoint_name;
                END
                ELSE
                    BEGIN TRANSACTION;

                BEGIN TRY
                    SET @key_name = ''''MS_Enckey_Exec_''''+CONVERT(varchar,@execution_id)
                    SET @certificate_name = ''''MS_Cert_Exec_''''+CONVERT(varchar,@execution_id) 

                    SET @sqlString = ''''OPEN SYMMETRIC KEY '''' + @key_name 
                        + '''' DECRYPTION BY CERTIFICATE '''' + @certificate_name  
                    EXECUTE sp_executesql @sqlString

                    SELECT [property_path],
                        [property_value]
                        FROM internal.[execution_property_override_values]
                        WHERE [execution_id] = @execution_id 
                        AND [sensitive] = 0
                    UNION
                    SELECT [property_path],
                        CONVERT(NVARCHAR, DECRYPTBYKEY([sensitive_property_value])) AS property_value
                        FROM internal.[execution_property_override_values]
                        WHERE [execution_id] = @execution_id 
                        AND [sensitive] = 1
 
                    SET @sqlString = ''''CLOSE SYMMETRIC KEY ''''+ @key_name
                    EXECUTE sp_executesql @sqlString             
                    IF @tran_count = 0
                        COMMIT TRANSACTION;
                END TRY
                BEGIN CATCH
                    IF @tran_count = 0 
                        ROLLBACK TRANSACTION;
                    ELSE IF XACT_STATE() <> -1
                        ROLLBACK TRANSACTION @savepoint_name;

                    SET @sqlString = ''''CLOSE SYMMETRIC KEY ''''+ @key_name
                    IF EXISTS (SELECT key_name FROM sys.openkeys WHERE key_name = @key_name)
                        EXECUTE sp_executesql @sqlString;
                    THROW;
                END CATCH
                RETURN 0
            '
            SET @cmd = N'EXEC SSISDB.dbo.sp_executesql @statement=N''' + @rawCmd + ''''
            EXEC sp_executesql @cmd
            PRINT 'Stored procedure [internal].[get_execution_property_override_values] has been recreated.'
        END

        IF OBJECT_ID (N'SSISDB.[internal].[configure_execution_encryption_algorithm]', N'P') IS NULL
        BEGIN
            SET @rawCmd = N'
            CREATE PROCEDURE [internal].[configure_execution_encryption_algorithm]
                @algorithm_name     nvarchar(255),
                @operation_id       bigint
            WITH EXECUTE AS ''''AllSchemaOwner''''
            AS
                SET NOCOUNT ON
                IF (@algorithm_name IS NULL)
                BEGIN
                    RAISERROR(27100, 16, 2, N''''algorithm_name'''') WITH NOWAIT
                    RETURN 1;
                END

                DECLARE @execution_id bigint
                DECLARE @decrypt_values [internal].[decrypted_data_table]
                DECLARE @decrypt_property_override_values [internal].[decrypted_data_table]

                DECLARE @key_name               [internal].[adt_name]
                DECLARE @certificate_name       [internal].[adt_name]
                DECLARE @sqlString              nvarchar(1024)

                SET TRANSACTION ISOLATION LEVEL SERIALIZABLE     
                DECLARE @tran_count INT = @@TRANCOUNT;          
                DECLARE @savepoint_name NCHAR(32);             
                IF @tran_count > 0                            
                BEGIN                                        
                    SET @savepoint_name = REPLACE(CONVERT(NCHAR(36), NEWID()), N''''-'''', N'''''''');
                    SAVE TRANSACTION @savepoint_name;
                END
                ELSE
                    BEGIN TRANSACTION;

                BEGIN TRY

                -- check if there are any active operations
                IF EXISTS (SELECT operation_id FROM [internal].[operations]
                    WHERE [status] IN (2, 5)
                    AND   [operation_id] <> @operation_id )
                BEGIN
                    RAISERROR(27139, 16, 1) WITH NOWAIT
                    RETURN 1
                END

                -- 1 get all the execution id by using cursor
                DECLARE execution_cursor CURSOR LOCAL
                    FOR SELECT [execution_id] FROM [internal].[executions]
                OPEN execution_cursor

                FETCH NEXT FROM execution_cursor
                    INTO @execution_id

                -- For each execution
                WHILE (@@FETCH_STATUS = 0)
                BEGIN
                    -- Clear the table valued parameter that stores decrypted value
                    DELETE @decrypt_values
                    DELETE @decrypt_property_override_values

                    -- Generate the certificate name and symmetric key name
                    SET @key_name = ''''MS_Enckey_Exec_''''+CONVERT(varchar(1024),@execution_id)
                    SET @certificate_name = ''''MS_Cert_Exec_''''+CONVERT(varchar(1024),@execution_id)

                    SELECT @sqlString = ''''OPEN SYMMETRIC KEY '''' + @key_name + '''' DECRYPTION BY CERTIFICATE ''''+ @certificate_name
                    EXECUTE sp_executesql @sqlString

                    --INSERT sensitive execution parameter values into TVPs
                    INSERT @decrypt_values 
                        SELECT [execution_parameter_id], DECRYPTBYKEY(sensitive_parameter_value)
                        FROM [internal].[execution_parameter_values] 
                        WHERE [execution_id] = @execution_id
                        AND [sensitive] = 1
                        AND [value_set] = 1

                    INSERT @decrypt_property_override_values 
                        SELECT [property_id], DECRYPTBYKEY(sensitive_property_value)
                        FROM [internal].[execution_property_override_values] 
                        WHERE [execution_id] = @execution_id
                        AND [sensitive] = 1

                    --Close symmetric key
                    SELECT @sqlString = ''''CLOSE SYMMETRIC KEY ''''+ @key_name
                    EXECUTE sp_executesql @sqlString

                    -- Delete the existing one and create the new symmetric key with one algorithm
                    SELECT @sqlString = ''''DROP SYMMETRIC KEY '''' + @key_name
                    EXECUTE sp_executesql @sqlString
                    SELECT @sqlString = ''''CREATE SYMMETRIC KEY ''''+ @key_name + '''' WITH ALGORITHM = '''' 
                        + @algorithm_name + '''' ENCRYPTION BY CERTIFICATE '''' + @certificate_name
                    EXECUTE sp_executesql @sqlString

                    -- Open the new symmetric key
                    SELECT @sqlString = ''''OPEN SYMMETRIC KEY '''' + @key_name + '''' DECRYPTION BY CERTIFICATE ''''+ @certificate_name
                    EXECUTE sp_executesql @sqlString

                    -- Update the value in [internal].[execution_parameter_values]
                    UPDATE [internal].[execution_parameter_values] 
                        SET sensitive_parameter_value =  EncryptByKey(KEY_GUID(@key_name),src.value)
                        FROM @decrypt_values src
                        WHERE execution_parameter_id = src.id

                    -- Update the values in [internal].[execution_property_override_values]
                    UPDATE [internal].[execution_property_override_values] 
                        SET sensitive_property_value =  EncryptByKey(KEY_GUID(@key_name),src.value)
                        FROM @decrypt_property_override_values src
                        WHERE property_id = src.id

                    -- close the new symmetric key
                    SELECT @sqlString = ''''CLOSE SYMMETRIC KEY ''''+ @key_name
                    EXECUTE sp_executesql @sqlString

                    -- Go on with the next execution id
                    FETCH NEXT FROM execution_cursor
                    INTO @execution_id
                END
                CLOSE execution_cursor
                DEALLOCATE execution_cursor

                IF @tran_count = 0
                    COMMIT TRANSACTION;
            END TRY
            BEGIN CATCH
                IF @tran_count = 0 
                    ROLLBACK TRANSACTION;
                ELSE IF XACT_STATE() <> -1
                    ROLLBACK TRANSACTION @savepoint_name;

                -- If the cursor is still open, close it
                IF (CURSOR_STATUS(''''local'''', ''''execution_cursor'''') = 1 
                    OR CURSOR_STATUS(''''local'''', ''''execution_cursor'''') = 0)
                BEGIN
                    CLOSE execution_cursor
                    DEALLOCATE execution_cursor
                END

                IF (@key_name <> '''''''')
                BEGIN
                    SET @sqlString = ''''CLOSE SYMMETRIC KEY ''''+ @key_name
                    IF EXISTS (SELECT key_name FROM sys.openkeys WHERE key_name = @key_name)
                    EXECUTE sp_executesql @sqlString
                END;
                THROW;
            END CATCH
            RETURN 0
            '
            SET @cmd = N'EXEC SSISDB.dbo.sp_executesql @statement=N''' + @rawCmd + ''''
            EXEC sp_executesql @cmd
            PRINT 'Stored procedure [internal].[configure_execution_encryption_algorithm] has been recreated.'
        END

        IF OBJECT_ID (N'SSISDB.[catalog].[set_execution_property_override_value]', N'P') IS NULL
        BEGIN
            SET @rawCmd = N'
            CREATE PROCEDURE [catalog].[set_execution_property_override_value]
            @execution_id       bigint,   -- id of the execution
            @property_path      nvarchar(4000), -- the path of the property
            @property_value     nvarchar(max),  -- the value of the property
            @sensitive          bit

            WITH EXECUTE AS ''''AllSchemaOwner''''
            AS 
            SET NOCOUNT ON
    
            DECLARE @caller_id     int
            DECLARE @caller_name   [internal].[adt_sname]
            DECLARE @caller_sid    [internal].[adt_sid]
            DECLARE @suser_name    [internal].[adt_sname]
            DECLARE @suser_sid     [internal].[adt_sid]
                
            --Get caller id.
            EXECUTE AS CALLER
                EXEC [internal].[get_user_info]
                    @caller_name OUTPUT,
                    @caller_sid OUTPUT,
                    @suser_name OUTPUT,
                    @suser_sid OUTPUT,
                    @caller_id OUTPUT;
                    /*Since AllSchemaOwner is a dbo, it do not have the permission*/
                    /*to check the type of sysadmin, add additional check which execute as caller*/
                IF(
                    EXISTS(SELECT [name]
                            FROM sys.server_principals
                            WHERE [sid] = @suser_sid AND [type] = ''''S'''')  --Sysadmin account
                    OR
                    EXISTS(SELECT [name]
                            FROM sys.database_principals
                            WHERE ([sid] = @caller_sid AND [type] = ''''S'''')) --Is caller a sql account?
                    )
                BEGIN
                    RAISERROR(27123, 16, 1) WITH NOWAIT
                    RETURN 1
                END
            REVERT
            /*Check whether the caller is a SQL account*/
            IF(
                    EXISTS(SELECT [name]
                            FROM sys.server_principals
                            WHERE [sid] = @suser_sid AND [type] = ''''S'''')  --SA account
                    OR
                    EXISTS(SELECT [name]
                            FROM sys.database_principals
                            WHERE ([sid] = @caller_sid AND [type] = ''''S'''')) --Is caller a sql account?
                    )
            BEGIN
                    RAISERROR(27123, 16, 1) WITH NOWAIT
                    RETURN 1
            END
    
            DECLARE @result int
            DECLARE @id bigint
            DECLARE @sensitive_value varbinary(MAX)
            DECLARE @calculated_property_value nvarchar(MAX)
            DECLARE @return_value           bit = 1
    
            IF (@execution_id IS NULL OR @property_path IS NULL OR @property_value IS NULL)
            BEGIN
                RAISERROR(27138, 16 , 1) WITH NOWAIT 
                RETURN 1 
            END   
    
            IF @execution_id <= 0
            BEGIN
                RAISERROR(27101, 16 , 1, N''''execution_id'''') WITH NOWAIT
                RETURN 1;
            END
    
            DECLARE @sqlString              nvarchar(1024)
            DECLARE @key_name               [internal].[adt_name]
            DECLARE @certificate_name       [internal].[adt_name]
            DECLARE @encryption_algorithm   nvarchar(255)

            SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
            DECLARE @tran_count INT = @@TRANCOUNT;
            DECLARE @savepoint_name NCHAR(32);
            IF @tran_count > 0
            BEGIN
                SET @savepoint_name = REPLACE(CONVERT(NCHAR(36), NEWID()), N''''-'''', N'''''''');
                SAVE TRANSACTION @savepoint_name;
            END
            ELSE
                BEGIN TRANSACTION;

            BEGIN TRY 
            EXECUTE AS CALLER
            SET @result = [internal].[check_permission] 
            (
                4,
                @execution_id,
                2
            ) 
            REVERT
        
            IF @result = 0
            BEGIN
                RAISERROR(27103 , 16 , 1, @execution_id) WITH NOWAIT
            END  
        
            DECLARE @project_id bigint
            DECLARE @status int
            EXECUTE AS CALLER
                SELECT @project_id = [object_id], @status = [status]
                FROM [catalog].[operations]
                WHERE [operation_id] = @execution_id 
                    AND [object_type] = 20
                    AND [operation_type] = 200
            REVERT
        
            IF (@project_id IS NULL)
            BEGIN
                RAISERROR(27103 , 16 , 1, @execution_id) WITH NOWAIT
            END
       
            IF  @status <> 1
            BEGIN
                RAISERROR(27225 , 16 , 1) WITH NOWAIT
            END
       
            IF @sensitive = 1
            BEGIN
                SET @key_name = ''''MS_Enckey_Exec_''''+CONVERT(varchar,@execution_id)
                SET @certificate_name = ''''MS_Cert_Exec_''''+CONVERT(varchar,@execution_id) 
     
                SET @sqlString = ''''OPEN SYMMETRIC KEY '''' + @key_name 
                    + '''' DECRYPTION BY CERTIFICATE '''' + @certificate_name  
                EXECUTE sp_executesql @sqlString
            
                SET @sensitive_value = EncryptByKey(KEY_GUID(@key_name),CONVERT(varbinary(4000),@property_value))
                SET @calculated_property_value = NULL
            
                SET @sqlString = ''''CLOSE SYMMETRIC KEY ''''+ @key_name
                EXECUTE sp_executesql @sqlString  
            END

            ELSE

            BEGIN
                SET @sensitive_value = NULL
                SET @calculated_property_value = @property_value
            END
            
            IF EXISTS 
            (
                SELECT 1
                FROM [internal].[execution_property_override_values]
                WHERE execution_id = @execution_id
                    AND property_path = @property_path
            )
            BEGIN
                UPDATE [internal].[execution_property_override_values]
                SET
                    property_value = @calculated_property_value,
                    sensitive_property_value = @sensitive_value,
                    sensitive = @sensitive
            END

            ELSE

            BEGIN
                INSERT INTO [internal].[execution_property_override_values]
                (
                    execution_id,
                    property_path,
                    sensitive,
                    property_value,
                    sensitive_property_value
                )
                VALUES
                (
                    @execution_id,
                    @property_path,
                    @sensitive,
                    @calculated_property_value,
                    @sensitive_value
                )
            END

            IF @tran_count = 0
                COMMIT TRANSACTION;
            END TRY
    
            BEGIN CATCH

                IF @tran_count = 0 
                    ROLLBACK TRANSACTION;
                ELSE IF XACT_STATE() <> -1
                    ROLLBACK TRANSACTION @savepoint_name;

                THROW;
            END CATCH
     
            RETURN 0
                    '
            SET @cmd = N'EXEC SSISDB.dbo.sp_executesql @statement=N''' + @rawCmd + ''''
            EXEC sp_executesql @cmd
            PRINT 'Stored procedure [catalog].[set_execution_property_override_value] has been recreated.'
        END

        --3. grant the permission on new one
        IF OBJECT_ID (N'SSISDB.[catalog].[create_execution]', N'P') IS NOT NULL
        BEGIN
            SET @rawCmd = N'GRANT EXECUTE ON [catalog].[create_execution] TO [PUBLIC]'
            SET @cmd = N'EXEC SSISDB.dbo.sp_executesql @statement=N''' + @rawCmd + ''''
            EXEC sp_executesql @cmd
            PRINT 'Permissions on [catalog].[create_execution] has been granted.'
        END

        IF OBJECT_ID (N'SSISDB.[catalog].[set_execution_parameter_value]', N'P') IS NOT NULL
        BEGIN
            SET @rawCmd = N'GRANT EXECUTE ON [catalog].[set_execution_parameter_value] TO [PUBLIC]'
            SET @cmd = N'EXEC SSISDB.dbo.sp_executesql @statement=N''' + @rawCmd + ''''
            EXEC sp_executesql @cmd
            PRINT 'Permissions on [catalog].[set_execution_parameter_value] has been granted.'
        END

        IF OBJECT_ID (N'SSISDB.[catalog].[configure_catalog]', N'P') IS NOT NULL
        BEGIN
            SET @rawCmd = N'GRANT EXECUTE ON [catalog].[configure_catalog] TO [SSIS_ADMIN]'
            SET @cmd = N'EXEC SSISDB.dbo.sp_executesql @statement=N''' + @rawCmd + ''''
            EXEC sp_executesql @cmd
            PRINT 'Permissions on [catalog].[configure_catalog] has been granted.'
        END

        IF OBJECT_ID (N'SSISDB.[internal].[cleanup_server_retention_window]', N'P') IS NOT NULL
        BEGIN
            SET @rawCmd = N'GRANT EXECUTE ON [internal].[cleanup_server_retention_window] TO ##MS_SSISServerCleanupJobUser##'
            SET @cmd = N'EXEC SSISDB.dbo.sp_executesql @statement=N''' + @rawCmd + ''''
            EXEC sp_executesql @cmd
            PRINT 'Permissions on [internal].[cleanup_server_retention_window] has been granted.'
        END

        IF OBJECT_ID (N'SSISDB.[internal].[get_execution_values]', N'P') IS NOT NULL
        BEGIN
            SET @rawCmd = N'GRANT EXECUTE ON [internal].[get_execution_values] TO [PUBLIC]'
            SET @cmd = N'EXEC SSISDB.dbo.sp_executesql @statement=N''' + @rawCmd + ''''
            EXEC sp_executesql @cmd
            PRINT 'Permissions on [internal].[get_execution_values] has been granted.'
        END

        IF OBJECT_ID (N'SSISDB.[internal].[get_execution_property_override_values]', N'P') IS NOT NULL
        BEGIN
            SET @rawCmd = N'GRANT EXECUTE ON [internal].[get_execution_property_override_values] TO [PUBLIC]'
            SET @cmd = N'EXEC SSISDB.dbo.sp_executesql @statement=N''' + @rawCmd + ''''
            EXEC sp_executesql @cmd
            PRINT 'Permissions on [internal].[get_execution_property_override_values] has been granted.'
        END

        IF OBJECT_ID (N'SSISDB.[catalog].[set_execution_property_override_value]', N'P') IS NOT NULL
        BEGIN
            SET @rawCmd = N'GRANT EXECUTE ON [catalog].[set_execution_property_override_value] TO [PUBLIC]'
            SET @cmd = N'EXEC SSISDB.dbo.sp_executesql @statement=N''' + @rawCmd + ''''
            EXEC sp_executesql @cmd
            PRINT 'Permissions on [catalog].[set_execution_property_override_value] has been granted.'
        END

        --3.1 ADD Noncluster index for SSISDB
        PRINT 'Remove Noncluster Index in SSISDB'

        IF EXISTS (SELECT * FROM SSISDB.sys.indexes WHERE name = 'IX_OperationMessages_Operation_id'  AND object_id = OBJECT_ID('SSISDB.internal.operation_messages'))
        DROP INDEX IX_OperationMessages_Operation_id ON SSISDB.internal.operation_messages

        IF EXISTS (SELECT * FROM SSISDB.sys.indexes WHERE name = 'IX_ExecutableStatistics_Execution_id'  AND object_id = OBJECT_ID('SSISDB.internal.executable_statistics'))
        DROP INDEX IX_ExecutableStatistics_Execution_id ON SSISDB.internal.executable_statistics

        IF EXISTS (SELECT * FROM SSISDB.sys.indexes WHERE name = 'Unique_sequence_id'  AND object_id = OBJECT_ID('SSISDB.internal.execution_component_phases'))
        DROP INDEX Unique_sequence_id ON SSISDB.internal.execution_component_phases

        CREATE NONCLUSTERED INDEX [Unique_sequence_id] 
        ON [SSISDB].[internal].[execution_component_phases] 
        (
            [sequence_id] ASC
        )

        IF EXISTS (SELECT * FROM SSISDB.sys.indexes WHERE name = 'IX_EventMessages_Operation_id'  AND object_id = OBJECT_ID('SSISDB.internal.event_messages'))
        DROP INDEX IX_EventMessages_Operation_id ON SSISDB.internal.event_messages

        IF EXISTS (SELECT * FROM SSISDB.sys.indexes WHERE name = 'IX_EventMessageContext_Operation_id'  AND object_id = OBJECT_ID('SSISDB.internal.event_message_context'))
        DROP INDEX IX_EventMessageContext_Operation_id ON SSISDB.internal.event_message_context


        IF EXISTS (SELECT * FROM SSISDB.sys.indexes WHERE name = 'IX_internal_object_parameters_inc'  AND object_id = OBJECT_ID('SSISDB.internal.object_parameters'))
        DROP INDEX IX_internal_object_parameters_inc ON SSISDB.internal.object_parameters

        IF EXISTS (SELECT * FROM SSISDB.sys.indexes WHERE name = 'IX_Operations_object_id'  AND object_id = OBJECT_ID('SSISDB.internal.operations'))
        DROP INDEX IX_Operations_object_id ON SSISDB.internal.operations

        --Finally, update the schema build number to server's build number
        SET @cmd = 'UPDATE [SSISDB].[internal].[catalog_properties] SET property_value = N''' + @targetVersion + ''' WHERE property_name = N''SCHEMA_BUILD'''
        EXEC sp_executesql @cmd
        PRINT 'Schema build in SSISDB has been updated to ' + @targetVersion

        --4. Change View

        DECLARE @CreateViewStatement NVARCHAR(MAX) 

        SET @CreateViewStatement = N'SELECT [object_type],
                [object_id],
                [permission_type], 
                [sid],
                [is_role],
                [is_deny]
        FROM     SSISDB.[internal].[object_permissions]
            WHERE     ([is_role] = 0 AND [sid] = USER_SID (DATABASE_PRINCIPAL_ID()))
            OR ([is_role] =1 AND IS_MEMBER(USER_NAME([internal].[get_principal_id_by_sid]([sid])))=1)'

        IF Object_ID(N'[SSISDB].[internal].[current_user_object_permissions]') IS NULL
            SET @CreateViewStatement = N'CREATE VIEW [internal].[current_user_object_permissions] AS ' + @CreateViewStatement
        ELSE    
            SET @CreateViewStatement = N'ALTER VIEW [internal].[current_user_object_permissions] AS ' + @CreateViewStatement

        SET @CreateViewStatement = N' USE '+ QUOTENAME(@ssis_database_name) +';  ' + 'EXEC(''' + @CreateViewStatement + ''')'

        EXEC(@CreateViewStatement)

		DECLARE @curr_level int
		SELECT @curr_level = property_value FROM SSISDB.internal.catalog_properties WHERE property_name = 'SERVER_OPERATION_ENCRYPTION_LEVEL'
		IF @curr_level = 1
		BEGIN
			UPDATE [SSISDB].[internal].[catalog_properties] 
			SET 
			[property_value]  = '3'
			WHERE property_name = 'SERVER_OPERATION_ENCRYPTION_LEVEL'
		END
		ELSE
		BEGIN
			UPDATE [SSISDB].[internal].[catalog_properties] 
			SET 
			[property_value]  = '4'
			WHERE property_name = 'SERVER_OPERATION_ENCRYPTION_LEVEL'
		END
END

PRINT '------------------------------------------------------'
PRINT 'Execution of SSIS_HOTFIX_UNINSTALL.SQL completed'
PRINT '------------------------------------------------------'
GO

